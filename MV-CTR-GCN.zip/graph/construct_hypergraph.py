# -*-coding:utf-8-*-
import torch
import numpy as np
import scipy.linalg


def construct_st_H(data):
    """

    Args:
        data: [n_frame, 3_view, 18joints], 3

    Returns:
        H: [18 * 3 * n_frames], 18 * n_frame np,array

    """
    views = 3
    joints = 25
    n_frame = int(len(data) / (views * joints))
    n_obj = views * joints * n_frame
    n_edge = joints
    H = np.ones((len(data), n_edge * views))* 0.00001
    for edg_idx in range(n_edge):
        for node_idx in range(edg_idx, len(data), joints):
            H[node_idx, edg_idx] = 1.0
    return H


def construct_spatial_H3():
    """

    Args:
        data: [n_frame, 3_view, 18joints], 3

    Returns:
        H: [18 * 3 * n_frames], 18 * n_frame

    """
    # 三个视角的对应点连到一个超边
    views = 3
    joints = 25
    n_frame = 1
    n_obj = joints
    # ori_index = [(0, 1, 2, 3, 20), (4, 5, 6, 7, 21, 22), (8, 9, 10, 11, 23, 24),(16, 17, 18, 19),(12, 13, 14, 15)]
    ori_index = [(0,1,20), (20,2,3),(4,20,8),(8,9,10),(10,11,23),(11,23,24),(4,5,6),(6,7,21),(7,21,22),(16,17,18),(17,18,19),(12,13,14),(13,14,15)]
    n_edge = len(ori_index)
    H = np.zeros((n_obj, n_edge))

    for edg_idx in range(n_edge):
        for j in range(len(ori_index[edg_idx])):
            node_idx = ori_index[edg_idx][j]
            H[node_idx, edg_idx] = 1.0

    #
    big_H = np.zeros((joints * n_frame, n_edge * n_frame))
    for i in range(n_frame):
        bias_x = i * joints
        bias_y = i * n_edge
        big_H[bias_x : bias_x + joints, bias_y : bias_y + n_edge] = H
    return big_H

def construct_spatial_H5():
    """

    Args:
        data: [n_frame, 3_view, 18joints], 3

    Returns:
        H: [18 * 3 * n_frames], 18 * n_frame

    """
    # 三个视角的对应点连到一个超边
    views = 3
    joints = 25
    n_frame = 1
    n_obj = joints
    ori_index = [(0, 1, 2, 3, 20), (4, 5, 6, 7, 21, 22), (8, 9, 10, 11, 23, 24),(16, 17, 18, 19),(12, 13, 14, 15)]
    # ori_index = [(0,1,20), (20,2,3),(4,20,8),(8,9,10),(10,11,23),(11,23,24),(4,5,6),(6,7,21),(7,21,22),(16,17,18),(17,18,19),(12,13,14),(13,14,15)]
    n_edge = len(ori_index)
    H = np.zeros((n_obj, n_edge))

    for edg_idx in range(n_edge):
        for j in range(len(ori_index[edg_idx])):
            node_idx = ori_index[edg_idx][j]
            H[node_idx, edg_idx] = 1.0

    #
    big_H = np.zeros((joints * n_frame, n_edge * n_frame))
    for i in range(n_frame):
        bias_x = i * joints
        bias_y = i * n_edge
        big_H[bias_x : bias_x + joints, bias_y : bias_y + n_edge] = H
    return big_H


def construct_temporal_H(data):
    """

    Args:
        data: [n_frame, 3_view, 18joints], 3

    Returns:
        H: [18 * 3 * n_frames], 18 * 3_view

    """
    views = 3
    joints = 25
    n_frame = int(len(data) / (views * joints))
    n_obj = len(data)
    n_edge = joints
    H = np.ones((n_obj, n_edge * n_frame)) * 0.00001
    for edg_idx in range(n_edge * views):
        for node_idx in range(edg_idx, len(data), joints * views):
            H[node_idx, edg_idx] = 1.0
    return H