# -*-coding:utf-8-*-
import torch.nn as nn
from ctrgcn import ModelSpa, ModelTem

class CombineModel(nn.Module):
    def __init__(self, num_class=60, num_point=25, num_person=2, graph=None, graph_args=dict(), in_channels=3,
                 drop_out=0, adaptive=True):
        super(CombineModel, self).__init__()

        self.m1 = ModelSpa()
        self.m2 = ModelTem()
        self.fc = nn.Linear()

    def forward(self, x):
        o1, x1 = self.m1(x)
        o2, x2 = self.m2(x)
        o3 = self.fc(x1, x2)
        return o1, o2, o3